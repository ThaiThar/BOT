import React from 'react'
import './battleStyle.css'

function battle() {
  return (
    <div className='battlecenter'>
      <div className='battlebox'>
        <div className='center-battle'></div>
        <div className='center-battle'></div>
        <div className='center-battle'></div>
      </div>
    </div>
  )
}

export default battle
