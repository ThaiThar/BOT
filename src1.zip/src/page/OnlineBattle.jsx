import { useEffect, useState } from "react";
import socket from "../realtime/socket";
import Bas from "../components/Bas";

export default function OnlineBattle() {
  const roomId = "ROOM123";
  const playerId = "P1";

  const [ready, setReady] = useState(false);
  const [battleState, setBattleState] = useState(null);
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    socket.connect();

    // Join ห้อง
    socket.emit("join_room", { roomId, playerId });

    // รับ state ตอนเข้าห้องครั้งแรก
    socket.on("init_state", ({ state, players }) => {
      setBattleState(state);
      setPlayers(players);
      setReady(true);
    });

    // รับ state ใหม่จากคนอื่น
    socket.on("update_state", ({ state }) => {
      setBattleState(state);
    });

    // รายชื่อผู้เล่นในห้อง
    socket.on("room_players", ({ players }) => {
      setPlayers(players);
    });

    // ออกจากห้องตอนปิด
    return () => {
      socket.emit("leave_room", { roomId, playerId });
      socket.disconnect();
    };
  }, []);

  // ฟังก์ชันส่ง state ขึ้น server ทุกครั้งที่มีการเปลี่ยน
  const syncState = (newState) => {
    setBattleState(newState);
    socket.emit("sync_state", {
      roomId,
      playerId,
      state: newState
    });
  };

  if (!ready) return <div>กำลังโหลดห้อง...</div>;

  return (
    <div>
      <h2>Online Room: {roomId}</h2>
      <p>Players: {players.join(", ")}</p>

      {/* ส่ง battleState และฟังก์ชัน sync ไปให้ Bas */}
      <Bas
        playerId={playerId}
        roomId={roomId}
        battleState={battleState}
        setBattleState={syncState}  // ให้ Bas เรียกอันนี้เพื่อ sync
      />
    </div>
  );
}
