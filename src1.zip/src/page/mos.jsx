import React from 'react'

function mos() {
  return (
    <div>
      มอส
    </div>
  )
}

export default mos
