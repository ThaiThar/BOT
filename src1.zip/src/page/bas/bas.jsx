import React from "react";
import "./style.css";

import Start from "./start/start.jsx";
import Center from "./center/center.jsx";
import End1 from "./end1/end1.jsx";
import HandButton from "./hand/HandButton.jsx";

function Bas({ playerId = "P1", battleState, setBattleState }) {
  
  // ป้องกัน error ตอนค่า state ยังไม่ถูกโหลด
  if (!battleState) {
    return <div>กำลังโหลดกระดาน...</div>;
  }

  // ฟังก์ชันอัปเดต state แบบรวม และ sync ขึ้น server
  const updateState = (change) => {
    const newState = { ...battleState, ...change };
    setBattleState(newState); // ฟังก์ชันนี้จะ sync ไป server ด้วย
  };

  return (
    <div className="fillborad">
      {/* แถบแสดงฝั่ง */}
      <div style={{ textAlign: "center", marginBottom: 4 }}>
        <span style={{ fontWeight: "bold" }}>
          กระดานของฝั่ง: {playerId}
        </span>
      </div>

      {/* ปุ่มและ UI โซนมือ */}
      <HandButton
        handCards={battleState.handCards}
        setHandCards={(v) => updateState({ handCards: v })}

        magicSlots={battleState.magicSlots}
        setMagicSlots={(v) => updateState({ magicSlots: v })}

        avatarSlots={battleState.avatarSlots}
        setAvatarSlots={(v) => updateState({ avatarSlots: v })}

        modSlots={battleState.modSlots}
        setModSlots={(v) => updateState({ modSlots: v })}

        end1Cards={battleState.end1Cards}
        setEnd1Cards={(v) => updateState({ end1Cards: v })}

        end2Cards={battleState.end2Cards}
        setEnd2Cards={(v) => updateState({ end2Cards: v })}
      />

      <div style={{ display: "flex" }}>

        {/* โซน Start */}
        <div className="start">
          <Start />
        </div>

        {/* โซน Center (หลักของกระดาน) */}
        <div className="center">
          <Center
            magicSlots={battleState.magicSlots}
            setMagicSlots={(v) => updateState({ magicSlots: v })}

            avatarSlots={battleState.avatarSlots}
            setAvatarSlots={(v) => updateState({ avatarSlots: v })}

            modSlots={battleState.modSlots}
            setModSlots={(v) => updateState({ modSlots: v })}

            setHandCards={(v) => updateState({ handCards: v })}

            end1Cards={battleState.end1Cards}
            setEnd1Cards={(v) => updateState({ end1Cards: v })}

            end2Cards={battleState.end2Cards}
            setEnd2Cards={(v) => updateState({ end2Cards: v })}

            deckCards={battleState.deckCards}
            setDeckCards={(v) => updateState({ deckCards: v })}
          />
        </div>

        {/* โซน End1 */}
        <div className="end1">
          <End1
            onDrawCard={(card) => {
              updateState({
                handCards: [...battleState.handCards, card]
              });
            }}

            deckCards={battleState.deckCards}
            setDeckCards={(v) => updateState({ deckCards: v })}

            end1Cards={battleState.end1Cards}
            setEnd1Cards={(v) => updateState({ end1Cards: v })}

            end2Cards={battleState.end2Cards}
            setEnd2Cards={(v) => updateState({ end2Cards: v })}

            handCards={battleState.handCards}
            setHandCards={(v) => updateState({ handCards: v })}
          />
        </div>
      </div>
    </div>
  );
}

export default Bas;
