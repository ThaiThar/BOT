import React from "react";
import Battle from "./page/battle/battle.jsx";
import BattleField from "./page/bas/BattleField.jsx";
import "./App.css";

function App() {
  return (
    <div className="borad">
      {/* <Battle /> */}
      <BattleField />
    </div>
  );
}

export default App;
